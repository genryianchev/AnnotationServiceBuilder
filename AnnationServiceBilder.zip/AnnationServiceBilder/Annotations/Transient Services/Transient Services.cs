﻿namespace AnnationServiceBilder.Data.Transient_Services
{
    [AttributeUsage(AttributeTargets.Class, Inherited = false, AllowMultiple = false)]
    public sealed class TransientServiceAttribute : Attribute
    {
    }
}
